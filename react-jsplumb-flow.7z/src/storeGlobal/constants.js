export const SET_NODE_LIST = 'global/SET_NODE_LIST';
export const SET_CURSOR = 'global/SET_CURSOR';
export const SET_MAIN_CONTAINER_HEIGHT = 'global/SET_MAIN_CONTAINER_HEIGHT';
export const SET_RERENDER = 'global/SET_RERENDER';
export const SET_DATASOURCE = 'global/SET_DATASOURCE';
export const CLEAR_OUT = 'global/CLEAR_OUT';
export const SAVE_WORKFLOW = 'global/SAVE_WORKFLOW';
export const Error = 'global/Error';
export const SET_NODE_FLOW_MENU = 'global/SET_NODE_FLOW_MENU';
export const SET_WORK_FLOW_MODE = 'global/SET_WORK_FLOW_MODE';
export const SET_MAIN_CONTAINER_POS = 'global/SET_MAIN_CONTAINER_POS';

