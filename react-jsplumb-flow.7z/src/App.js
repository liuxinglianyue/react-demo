// import React, { Component } from 'react';
// import Index from './components/Index';
// import './static/css/App.css';
// import store from "@/store";
// import { Provider } from "react-redux";
// import PropTypes from 'prop-types';
//
// export default class App extends Component {
//     constructor(props) {
//         super(props);
//         this.store = store;
//     }
//
//     render() {
//         return (
//             <Provider store={this.store}>
//                 <Index {...this.props} />
//             </Provider>
//         );
//     }
// }
// App.defaultProps={
//     XWidth: 0,
//     YHeight: 0
// };
//
// App.propTypes={
//     id:PropTypes.number,
//     XWidth: PropTypes.number,
//     YHeight: PropTypes.number
// };

