import '@/static/css/index.css';
import 'jsplumb';
import ForwardJSPlumbFlow from "./indexForward";
import ReverseJSPlumbFlow from "./indexReverse";
import ExhibitionJSPlumbFlow from "./components/ExhibitionJSPlumbFlow";
export { ForwardJSPlumbFlow, ReverseJSPlumbFlow, ExhibitionJSPlumbFlow }