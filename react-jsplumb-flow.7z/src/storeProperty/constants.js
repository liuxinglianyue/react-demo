export const SET_PROPERTY = 'property/SET_PROPERTY';
export const BANK_FORM_LIST = 'property/BANK_FORM_LIST';
export const ERROR = 'property/ERROR';
