import React, {Component, Fragment} from "react";
import HocFormComponent from "../HocUI/HocFormComponent";


@HocFormComponent()
class PoolLaneDirection extends Component{
    render() {
        return (<Fragment></Fragment>)
    }
}
export default PoolLaneDirection;