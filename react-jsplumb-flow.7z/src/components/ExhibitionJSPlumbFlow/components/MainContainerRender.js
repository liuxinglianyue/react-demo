import React, { Component } from "react";

export default class MainContainerRender extends Component {

    render() {
        return (
            <div id={ "diagramContainerExhibition" }>maincontainer</div>
        )
    }
}