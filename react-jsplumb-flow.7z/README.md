# react-jsplumb-flow

在React中使用jsPlumb.js绘制流程图.

# 如何运行此项目

1.拉取代码后，本地执行yarn install，耐心等待依赖安装完毕。<br>
2.执行 npm run dev, 项目运行localhost:3000，开始你的表演。

# 项目展示
![avatar](/src/static/img/1111.png)
